# scikit-learn bootstrap
from sklearn.utils import resample
import numpy as np
# data sample

def Augment(val_l1, label):
    # prepare bootstrap sample
    boot_1 = resample(val_l1, replace=True, n_samples=30000, random_state=1)
    # out of bag observations
    oob = [x for x in val_l1 if x not in boot_1]
    # np.savetxt("Processed//Augmented_data_1.csv", boot_1, delimiter=',', fmt="%s")
    lab = label[:,0]
    lab = np.concatenate((lab, lab))
    lab_1 = np.resize(lab, (30000, 1))
    # np.savetxt("Processed//Augmented_label_1.csv", lab_1, delimiter=',', fmt="%s")
    return boot_1, lab_1

