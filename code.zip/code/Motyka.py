import numpy as np

def motyka(a, b, Mot):
    ii = len(b)
    up = 0
    down = 0
    for i in range(ii):
        up+= min(a[i], b[i])
        down+= (a[i] + b[i])
        q = up/down
        return 1 - q



def Similarity(normalized, label, N_features):
    Mot_l1 = []
    Sel_features_l5 = []
    a = normalized.shape[1]
    for j in range(a):
        q = motyka(normalized[:, j], label[:, 0], Mot_l1)
        Mot_l1.append(q)
    aa = np.argsort(Mot_l1)
    Mot_l1_feat_ind = aa[:N_features]
    for features in (Mot_l1_feat_ind):
        sel_feat = normalized[:, features]
        Sel_features_l5.append(sel_feat)
    return Sel_features_l5


