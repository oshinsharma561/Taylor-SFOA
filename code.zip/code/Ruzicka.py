import numpy as np
import pandas as pd

Ruz = []
def ruzicka(a, b, Ruz):
    ii = len(b)
    up = 0
    down = 0
    for i in range(ii):
        up+= min(a[i], b[i])
        down+= max(a[i], b[i])
        q = up/down
        return q



def Similarity(normalized, label, N_features):
    Ruz_l1 = []
    Sel_features_l1 = []
    a = normalized.shape[1]
    for j in range(a):
        q = ruzicka(normalized[:, j], label[:, 0], Ruz_l1)
        Ruz_l1.append(q)
    aa = np.argsort(Ruz_l1)
    Ruz_l1_feat_ind = aa[:N_features]
    for features in (Ruz_l1_feat_ind):
        sel_feat = normalized[:, features]
        Sel_features_l1.append(sel_feat)
    return Sel_features_l1




