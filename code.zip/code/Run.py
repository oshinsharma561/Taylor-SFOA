import numpy as np

import DRN

import pandas as pd
import Ruzicka, Motyka
import Augmentation

def dice_coef(Sel_features_l1, Sel_features_l5, label):
    con_l1 = np.concatenate((Sel_features_l1, Sel_features_l5))
    intersection = np.outer(np.arccos(con_l1), label[0])
    intersection[np.isnan(intersection)] = 1
    mod1 = np.linalg.norm(intersection)
    mod2 = np.linalg.norm(label[0])
    val_l1 = 2. * intersection / (mod1 + mod2)
    return val_l1


def callmain(tp, dts):
    #########  Reading the datasets  ##########
    data = pd.read_csv("Dataset/Dataset.csv", header=None)
    data = data[1:]  # removing the attribute names

 ################## data normalization
    pre_data = data.iloc[:, :16]
    # np.savetxt("Processed/Pre_processed_data.csv", pre_data, delimiter=',', fmt='%s')
    pre_lab = data.iloc[:, -4:]
    # np.savetxt("Processed/Pre_processed_labels.csv", pre_lab, delimiter=',', fmt='%s')
             ########## quantile normalization
    df_sorted = pd.DataFrame(np.sort(pre_data.values, axis=0), index=pre_data.index,
                             columns=pre_data.columns)  # Step 1: Order values in each column
    df_mean = df_sorted.mean(axis=1)  # Step2: Compute Row Means
    df_mean.index = np.arange(1, len(df_mean) + 1)
    pre_data.rank(method="min").astype(int)  # Step3: Use Average Values to each sample in the original order
    pre_data.rank(method="min").stack().astype(int)
    normalized_data = pre_data.rank(method="min").stack().astype(int).map(df_mean).unstack()
            ###### converting dataframe to array
    normalized = np.array(normalized_data)
    label = np.array(pre_lab)

    N_features = 8
    ######### feature selection using Ruzicka Similarity
    Sel_features_r = Ruzicka.Similarity \
        (normalized, label, N_features)
    ######### feature selection using Motyka Similarity
    Sel_features_m = Motyka.Similarity \
        (normalized, label, N_features)


       ########### feature fusion using dice coefficient
    fusd_data = dice_coef(Sel_features_r, Sel_features_m, label)

    ##########  Augmentation
    aug_data,aug_lab = Augmentation.Augment(fusd_data,label)

    tp=tp/100
    MSE, RMSE, MAE = [],[],[]



    print("\n Deep Residual Network running")
    MSE, RMSE, MAE = DRN.classify(aug_data, aug_lab, dts, tp, MSE, RMSE, MAE)
    return MSE, RMSE, MAE
