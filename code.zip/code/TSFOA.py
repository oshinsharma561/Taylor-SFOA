import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
from random import random
import numpy as np
import math

def algm():
    N, M = 10, 5    # row(sheep), column(search space)
    lb, ub = 0, 1   # lower & upper bound
    g, max_itr = 0, 100 # initial value, max. of iteration
    dim = 20
    d_min, d_max = 5, 10
    eta = np.random.random()
    re_best_fit = 0

    # Initial solution
    def generate_soln(n, m, Xmin, Xmax):
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                rand = np.random.random()
                tem.append(Xmin+(rand*(Xmax-Xmin)))     # initial position
            data.append(tem)
        return data

    def regenerate_soln(n, m, Xmin, Xmax):
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                rand = np.random.random()
                tem.append(Xmin+(rand*(Xmax-Xmin)))     # re-initialization of position
            data.append(tem)
        return data

    X = generate_soln(N, M, lb, ub)  # generate initial soln.

    def func(soln):
        Fit = []
        for i in range(len(soln)):
            F = 0
            for j in range(len(soln[i])):
                hr = np.random.random()
                F += soln[i][j]*hr
            Fit.append(F)
        return Fit

    def updated_omega():
        phase = np.random.uniform(0, 0.01)
        updated_omega = omega + phase
        return updated_omega

    def re_func(re_soln):
        Fit = []
        for i in range(len(re_soln)):
            F = 0
            for j in range(len(re_soln[i])):
                hr = np.random.random()
                F += re_soln[i][j]*hr
            Fit.append(F)
        return Fit

    Y = regenerate_soln(N, M, lb, ub)
    Fit = re_func(Y)  # Evaluating Objective function
    re_best_fit = np.min(Fit)

    def del_f(X, Y):
        diff = abs(re_best_fit - best_fit_now)
        return diff

    Fit = func(X)  # Evaluating Objective function
    best_fit_now = np.min(Fit)
    L_best = best_fit_now
    while g < max_itr:
        overall_fit, overall_best = [], []
        Fit = func(X)  # Evaluating Objective function
        best_fit_now = np.min(Fit)
        d = d_max - ((d_max - d_min) * g) / max_itr
        for i in range(N):
            omega = np.random.uniform(0, 160)
            for j in range(dim):
                sun = np.random.uniform(0, 100)
                if (sun == 1):
                    Aux = np.random.random()
                    hours_day = np.random.uniform(0, 50)
                    if (hours_day <= 24):
                        mode = X+(d*math.sin(omega))*((Aux*L_best)-X)

                    else:
                        mode=(4*X)-(X-1)*(1-(d*(math.sin(omega)))+ (5*(d*math.sin(omega))
                *(L_best))) /  (5-(2*(1-(d*math.sin(omega)))))  # proposed update equation

                else:
                    hours_day = np.random.uniform(0, 50)

            updated_omega = updated_omega()
            break
        break
    # break

    if (best_fit_now < re_best_fit):
        L_bst = best_fit_now
    else:
        L_bst = re_best_fit
    return L_bst

    return overall_fit, overall_best


