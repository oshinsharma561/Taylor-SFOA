import csv
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd



# to plot graph
def plot_graph(file,x_lab,y_lab,labels,tick_labels1):
    colorr = ['#3776ab','#FF7518','#3bab37','#D2042D','#ffff00','#fc5a50','#7b5ec6']
    plt.figure(figsize=(7, 5), dpi=120)
    with open(file + ".csv", 'rt') as f:  #######################file => file --> 1,5,9 -- 2,6,10 -- 3,7,11 -- 4,8,12

        # read & store data in array
        data = []
        content = csv.reader(f)  # content in csv
        for row in content:
            tem = []
            for col in row:
                tem.append(float(col))
            if (len(tem) > 0):  # to remove empty string in csv
                data.append(tem)
        data = np.transpose(data)
    result =data
    loc=[]

    # labels for bars
    # labels = ['ANN', 'SVM', 'ensemble_ML','SSA_DBN', 'Proposed jayaMLA_DFFNN ']  # x-axis labels
    tick_labels = tick_labels1  # metrics
    bar_width, s = 0.14, 0.0  # bar width, space between bars

    for i in range(len(result)):  # allocating location for bars
        if i is 0:  # initial location - 1st result
            tem = []
            for j in range(len(tick_labels)):
                tem.append(j + 1)
            loc.append(tem)
        else:  # location from 2nd result
            tem = []
            for j in range(len(loc[i - 1])):
                tem.append(loc[i - 1][j] + s + bar_width)
            loc.append(tem)

    # plotting a bar chart
    for i in range(len(result)):
        plt.bar(loc[i], result[i],color = colorr[i], label=labels[i], tick_label=tick_labels, width=bar_width, edgecolor='black')
    plt.subplots_adjust(bottom=0.3)
    plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), ncol=3,fontsize=11)
    # plt.legend()  # show a legend on the plot
    plt.xlabel(x_lab) ################## Delay
    plt.ylabel(y_lab)          ################## MSE, RMSE
    # plt.legend()
    plt.savefig(file + ".jpg")
    plt.show()
    # plt.legend(loc=(0.23, 0.06))     # loc=(0.25, 0.25) ---- 0.55, 0.7
    # plt.savefig(filename+".jpg")

    #plt.show()  # to show the plot

file1 = 'out_graphs_csv\\MAE_db1'
file2 = 'out_graphs_csv\\MAE_db2'
file3 = 'out_graphs_csv\\MAE_db3'
file4 = 'out_graphs_csv\\MAE_db4'
file5 = 'out_graphs_csv\\MSE_db1'
file6 = 'out_graphs_csv\\MSE_db2'
file7 = 'out_graphs_csv\\MSE_db3'
file8 = 'out_graphs_csv\\MSE_db4'
file9 = 'out_graphs_csv\\RMSE_db1'
file10 = 'out_graphs_csv\\RMSE_db2'
file11= 'out_graphs_csv\\RMSE_db3'
file12 = 'out_graphs_csv\\RMSE_db4'


x1_lab = 'Training data percentage'



y1_lab = 'MAE'

y2_lab = 'MSE'
y3_lab = 'RMSE'









legends = ['LSTM', 'FFT','DNN','LM','SAFER-BODNN','CNN','Proposed Taylor-SFOA_DRN']
labels1 = ['50','60', '70', '80', '90']


plot_graph(file1, x1_lab, y1_lab, legends, labels1)
plot_graph(file2, x1_lab, y1_lab, legends, labels1)
plot_graph(file3, x1_lab, y1_lab, legends, labels1)
plot_graph(file4, x1_lab, y1_lab, legends, labels1)
plot_graph(file5, x1_lab, y2_lab, legends, labels1)
plot_graph(file6, x1_lab, y2_lab, legends, labels1)
plot_graph(file7, x1_lab, y2_lab, legends, labels1)
plot_graph(file8, x1_lab, y2_lab, legends, labels1)
plot_graph(file9, x1_lab, y3_lab, legends, labels1)
plot_graph(file10, x1_lab, y3_lab, legends, labels1)
plot_graph(file11, x1_lab, y3_lab, legends, labels1)
plot_graph(file12, x1_lab, y3_lab, legends, labels1)

